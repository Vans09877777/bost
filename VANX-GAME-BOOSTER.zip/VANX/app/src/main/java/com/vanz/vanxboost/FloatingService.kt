package com.vanz.vanxboost

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

class CrosshairView(c: Context) : View(c) {
    var shape = 1
    private val d = resources.displayMetrics.density
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#00FF66"); style = Paint.Style.STROKE; strokeWidth = 2.5f * d }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#00FF66"); style = Paint.Style.FILL }
    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = 14f * d; val g = 5f * d
        when (shape) {
            1 -> {
                c.drawLine(cx - r, cy, cx - g, cy, line); c.drawLine(cx + g, cy, cx + r, cy, line)
                c.drawLine(cx, cy - r, cx, cy - g, line); c.drawLine(cx, cy + g, cx, cy + r, line)
            }
            2 -> c.drawCircle(cx, cy, 3f * d, dot)
            3 -> { c.drawCircle(cx, cy, r * 0.8f, line); c.drawCircle(cx, cy, 2f * d, dot) }
        }
    }
}

/** Gauge busur kecil untuk panel Genie. */
class ArcGaugeView(c: Context) : View(c) {
    var frac = 0f
    var value = "--"
    var label = ""
    var arcColor = Color.parseColor("#2F80FF")
    private val d = resources.displayMetrics.density
    private val rect = RectF()
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 6f * d; strokeCap = Paint.Cap.ROUND; setColor(Color.parseColor("#2A3142")) }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 6f * d; strokeCap = Paint.Cap.ROUND }
    private val tv = Paint(Paint.ANTI_ALIAS_FLAG).apply { setColor(Color.WHITE); textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD; textSize = 17f * d }
    private val tl = Paint(Paint.ANTI_ALIAS_FLAG).apply { setColor(Color.parseColor("#8B97B0")); textAlign = Paint.Align.CENTER; textSize = 8f * d }
    override fun onDraw(c: Canvas) {
        val pad = 8f * d
        rect.set(pad, pad, width - pad, height - pad)
        c.drawArc(rect, 135f, 270f, false, track)
        arc.color = arcColor
        c.drawArc(rect, 135f, 270f * frac.coerceIn(0f, 1f), false, arc)
        c.drawText(value, width / 2f, height / 2f + 3f * d, tv)
        c.drawText(label, width / 2f, height / 2f + 17f * d, tl)
    }
}

/**
 * Floating "Genie": bulatan V yang bisa digeser di samping layar, HUD FPS di atas layar,
 * crosshair, dan panel besar berisi gauge, tab mode, serta tombol fitur.
 */
class FloatingService : Service() {
    companion object {
        @Volatile var instance: FloatingService? = null
        val running = MutableStateFlow(false)
        fun start(c: Context, autoFps: Boolean = true) {
            c.startForegroundService(Intent(c, FloatingService::class.java).putExtra("autoFps", autoFps))
        }
        fun stop(c: Context) { c.stopService(Intent(c, FloatingService::class.java)) }
    }

    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT
    private val blue = Color.parseColor("#2F80FF")
    private val tileOff = Color.parseColor("#262C3A")
    private val dim = Color.parseColor("#8B97B0")
    private val modeOrder = listOf("BATTERY" to "HEMAT", "BALANCED" to "SEIMBANG", "PERFORMANCE" to "TURBO")

    private lateinit var wm: WindowManager
    private lateinit var store: Store
    private lateinit var bubbleLp: WindowManager.LayoutParams
    private lateinit var hudLp: WindowManager.LayoutParams
    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var bubble: TextView? = null
    private var hud: TextView? = null
    private var cross: CrosshairView? = null
    private var genie: LinearLayout? = null
    private var gview: LinearLayout? = null
    private var gweb: android.webkit.WebView? = null
    private var gRam: ArcGaugeView? = null
    private var gTemp: ArcGaugeView? = null
    private var tvDur: TextView? = null
    private var tvBat: TextView? = null
    private var tCross: TextView? = null
    private var tFps: TextView? = null
    private var tRec: TextView? = null
    private var tDnd: TextView? = null
    private var tAwake: TextView? = null
    private var tHud: TextView? = null
    private var tGhost: TextView? = null
    private var bubbleMode = 0 // 0 normal, 1 samar, 2 tak terlihat
    private val modeTabs = mutableListOf<TextView>()
    private var hudOn = true
    private var shown = true
    private var awake = false
    private var ready = false
    private var d = 1f

    private val loop = object : Runnable {
        override fun run() {
            val s = Sys.snap(this@FloatingService)
            val fpsTxt = if (FpsService.active.value) FpsService.fps.value.toString() else "--"
            hud?.text = "FPS %s  %.0f°C  %d%%  RAM %.1fG".format(fpsTxt, s.batTempC, s.batPct, s.ramAvailMb / 1024f)
            if (genie != null) refreshGenie(s)
            handler.postDelayed(this, 1000)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this; running.value = true
        d = resources.displayMetrics.density
        store = Store(this)
        wm = getSystemService(WindowManager::class.java)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("vanx_float", "Floating panel", NotificationManager.IMPORTANCE_MIN))
        val showPi = android.app.PendingIntent.getService(
            this, 1, Intent(this, FloatingService::class.java).putExtra("showBubble", true),
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
        )
        val showAct = Notification.Action.Builder(
            android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_menu_view), "Tampilkan tombol", showPi
        ).build()
        startForeground(4, Notification.Builder(this, "vanx_float").setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("VANX floating panel aktif").addAction(showAct).build())
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        buildHud(); buildCross(); buildBubble()
        handler.post(loop)
        ready = true
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (ready && i?.getBooleanExtra("showBubble", false) == true) { bubbleMode = 0; applyBubbleAlpha(); refreshNow() }
        if (ready && i?.getBooleanExtra("autoFps", false) == true && store.fpsAuto && !FpsService.active.value) {
            startActivity(Intent(this, CaptureActivity::class.java).putExtra("mode", "FPS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        return START_NOT_STICKY
    }

    private fun dp(v: Int) = (v * d).toInt()

    private fun lay(w: Int, h: Int, wt: Float = 0f, top: Int = 0) = LinearLayout.LayoutParams(w, h, wt).apply { topMargin = top }

    private fun params(touch: Boolean, w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or (if (touch) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE),
        PixelFormat.TRANSLUCENT
    )

    private fun rounded(fill: Int, stroke: Int, r: Float) = GradientDrawable().apply { setColor(fill); setStroke(2, stroke); cornerRadius = r }

    // ---------- HUD, crosshair, bubble ----------

    private fun buildHud() {
        val t = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 11f; typeface = Typeface.MONOSPACE
            setPadding(16, 6, 16, 6); background = rounded(Color.argb(150, 0, 0, 0), blue, 12f)
        }
        hudLp = params(false, WRAP, WRAP).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 24 }
        wm.addView(t, hudLp)
        hud = t
    }

    private fun buildCross() {
        val v = CrosshairView(this).apply { shape = store.xhair }
        val sz = dp(96)
        wm.addView(v, params(false, sz, sz).apply { gravity = Gravity.CENTER })
        cross = v
        applyVis()
    }

    private fun buildBubble() {
        val b = TextView(this).apply {
            text = "V"; textSize = 18f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.parseColor("#1B4FBF"), blue)).apply { shape = GradientDrawable.OVAL }
        }
        bubbleLp = params(true, dp(46), dp(46)).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = dp(120) }
        b.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = bubbleLp.x; sy = bubbleLp.y; tx = e.rawX; ty = e.rawY; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - tx; val dy = e.rawY - ty
                        if (abs(dx) > 10 || abs(dy) > 10) moved = true
                        if (moved) { bubbleLp.x = sx + dx.toInt(); bubbleLp.y = sy + dy.toInt(); wm.updateViewLayout(b, bubbleLp) }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) { if (genie == null) openGenie() else closeGenie() } else {
                        val dm = resources.displayMetrics
                        bubbleLp.x = if (bubbleLp.x + b.width / 2 < dm.widthPixels / 2) 0 else dm.widthPixels - b.width
                        bubbleLp.y = bubbleLp.y.coerceAtMost(dm.heightPixels - b.height).coerceAtLeast(0)
                        wm.updateViewLayout(b, bubbleLp)
                    }
                }
                return true
            }
        })
        wm.addView(b, bubbleLp)
        bubble = b
    }

    // ---------- panel Genie ----------

    private fun tile(emoji: String, label: String, onClick: () -> Unit): Pair<LinearLayout, TextView> {
        val icon = TextView(this).apply {
            text = emoji; textSize = 20f; gravity = Gravity.CENTER
            background = rounded(tileOff, Color.TRANSPARENT, 14f * d)
            layoutParams = LinearLayout.LayoutParams(dp(54), dp(54))
        }
        val lab = TextView(this).apply {
            text = label; textSize = 10f; gravity = Gravity.CENTER; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
            setTextColor(Color.parseColor("#C9D3E6")); setPadding(0, dp(3), 0, 0)
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
            addView(icon); addView(lab)
            setOnClickListener { onClick() }
        }
        return box to icon
    }

    private fun openGenie() {
        if (genie != null) return
        val dm = resources.displayMetrics
        val w = minOf(dp(450), (dm.widthPixels * 0.64f).toInt())
        val title = TextView(this).apply { text = "VANX GENIE"; textSize = 12f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD }
        val off = TextView(this).apply {
            text = "MATIKAN"; textSize = 10f; setTextColor(Color.parseColor("#FF6B6B")); setPadding(dp(8), dp(4), dp(8), dp(4))
            setOnClickListener { stopSelf() }
        }
        val close = TextView(this).apply {
            text = "✕"; textSize = 16f; setTextColor(Color.parseColor("#9AA7C0")); setPadding(dp(8), 0, dp(2), 0)
            setOnClickListener { closeGenie() }
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(title, lay(0, WRAP, 1f)); addView(off); addView(close)
        }

        val gr = ArcGaugeView(this); val gt = ArcGaugeView(this)
        gRam = gr; gTemp = gt
        val dur = TextView(this).apply { text = "--:--"; textSize = 20f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER }
        val durLab = TextView(this).apply { text = "Durasi game"; textSize = 10f; setTextColor(dim); gravity = Gravity.CENTER }
        val bat = TextView(this).apply { text = "--%"; textSize = 20f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER }
        val batLab = TextView(this).apply { text = "Baterai"; textSize = 10f; setTextColor(dim); gravity = Gravity.CENTER }
        tvDur = dur; tvBat = bat
        val durCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; addView(dur); addView(durLab) }
        val batCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; addView(bat); addView(batLab) }
        val gaugeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(durCol, lay(0, WRAP, 1f))
            addView(gr, lay(dp(76), dp(76)))
            addView(gt, lay(dp(76), dp(76)))
            addView(batCol, lay(0, WRAP, 1f))
        }

        modeTabs.clear()
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        modeOrder.forEachIndexed { i, (m, label) ->
            val t = TextView(this@FloatingService).apply {
                text = label; textSize = 11f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
                setPadding(0, dp(8), 0, dp(8)); setOnClickListener { setMode(m) }
            }
            modeTabs.add(t)
            tabs.addView(t, lay(0, WRAP, 1f).apply { if (i > 0) leftMargin = dp(6) })
        }

        val (b1, i1) = tile("🎯", "Crosshair") { cycleCross(); refreshNow() }
        val (b2, _) = tile("📷", "Screenshot") { capture("SHOT") }
        val (b3, i3) = tile("⏺", "Rekam") { if (CaptureService.recording.value) CaptureService.stop(this) else capture("REC") }
        val (b4, i4) = tile("🎮", "FPS meter") { if (FpsService.active.value) FpsService.stop(this) else capture("FPS"); refreshNow() }
        val (b5, i5) = tile("🔕", "Senyap") { toggleDnd() }
        val (b6, _) = tile("🧹", "Bersihkan RAM") { cleanRam() }
        val (b7, i7) = tile("💡", "Layar nyala") { toggleAwake(); refreshNow() }
        val (b8, i8) = tile("📶", "HUD FPS") { hudOn = !hudOn; applyVis(); refreshNow() }
        val (b9, _) = tile("🌐", "Google") { openGoogle() }
        val (b10, i10) = tile("👻", "Samarkan") { cycleBubble() }
        tCross = i1; tRec = i3; tFps = i4; tDnd = i5; tAwake = i7; tHud = i8; tGhost = i10
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; addView(b1); addView(b2); addView(b3); addView(b4); addView(b5) }
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; addView(b6); addView(b7); addView(b8); addView(b9); addView(b10) }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(12))
            background = rounded(Color.argb(240, 11, 17, 28), Color.argb(110, 47, 128, 255), 18f * d)
            addView(header)
            addView(gaugeRow, lay(MATCH, WRAP, 0f, dp(4)))
            addView(tabs, lay(MATCH, WRAP, 0f, dp(8)))
            addView(row1, lay(MATCH, WRAP, 0f, dp(10)))
            addView(row2, lay(MATCH, WRAP, 0f, dp(6)))
        }
        val left = bubbleLp.x + (bubble?.width ?: 0) / 2 < dm.widthPixels / 2
        val p = params(true, w, WRAP).apply {
            gravity = (if (left) Gravity.START else Gravity.END) or Gravity.CENTER_VERTICAL
            x = dp(60)
        }
        wm.addView(root, p)
        genie = root
        refreshGenie(Sys.snap(this))
    }

    private fun closeGenie() {
        genie?.let { v -> runCatching { wm.removeView(v) } }
        genie = null
        gRam = null; gTemp = null; tvDur = null; tvBat = null
        tCross = null; tFps = null; tRec = null; tDnd = null; tAwake = null; tHud = null; tGhost = null
        modeTabs.clear()
    }

    private fun setOn(icon: TextView?, on: Boolean) {
        icon?.background = rounded(if (on) blue else tileOff, Color.TRANSPARENT, 14f * d)
    }

    private fun refreshNow() { if (genie != null) refreshGenie(Sys.snap(this)) }

    private fun refreshGenie(s: Snap) {
        val ramF = s.ramUsedMb.toFloat() / s.ramTotalMb.coerceAtLeast(1)
        gRam?.let { it.frac = ramF; it.value = "${(ramF * 100).toInt()}%"; it.label = "RAM"; it.invalidate() }
        gTemp?.let {
            it.frac = (s.batTempC - 20f) / 40f; it.value = "%.0f°".format(s.batTempC); it.label = "SUHU"
            it.arcColor = if (s.batTempC >= 42f) Color.parseColor("#FF6B6B") else blue
            it.invalidate()
        }
        tvBat?.text = "${s.batPct}%"
        val sess = GameSessionService.state.value
        tvDur?.text = if (sess == null) "--:--" else {
            val el = (SystemClock.elapsedRealtime() - sess.startMs) / 1000
            "%d:%02d:%02d".format(el / 3600, el % 3600 / 60, el % 60)
        }
        setOn(tFps, FpsService.active.value)
        val rec = CaptureService.recording.value
        setOn(tRec, rec); tRec?.text = if (rec) "⏹" else "⏺"
        setOn(tCross, (cross?.shape ?: 0) != 0)
        setOn(tHud, hudOn)
        setOn(tAwake, awake)
        setOn(tGhost, bubbleMode != 0)
        val nm = getSystemService(NotificationManager::class.java)
        setOn(tDnd, nm.isNotificationPolicyAccessGranted && nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL)
        val cur = store.profile("_global").mode
        modeTabs.forEachIndexed { i, t ->
            val on = modeOrder[i].first == cur
            t.background = rounded(if (on) blue else tileOff, Color.TRANSPARENT, 10f * d)
            t.setTextColor(if (on) Color.WHITE else Color.parseColor("#C9D3E6"))
        }
    }

    // ---------- aksi ----------

    private fun setMode(m: String) {
        store.saveProfile("_global", store.profile("_global").copy(mode = m))
        GameSessionService.state.value?.let { s -> store.saveProfile(s.pkg, store.profile(s.pkg).copy(mode = m)) }
        if (m == "PERFORMANCE") store.minAnim = true
        refreshNow()
        Toast.makeText(this, "Mode: " + (modeOrder.firstOrNull { it.first == m }?.second ?: m), Toast.LENGTH_SHORT).show()
    }

    private fun cycleCross() {
        val c = cross ?: return
        c.shape = (c.shape + 1) % 4
        store.xhair = c.shape
        c.invalidate(); applyVis()
    }

    private fun capture(mode: String) {
        closeGenie()
        startActivity(Intent(this, CaptureActivity::class.java).putExtra("mode", mode).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** Google sebagai jendela floating (mini browser): bisa digeser, diubah ukurannya, dan diatur transparansinya. */
    private fun openGoogle() {
        closeGenie()
        if (gview != null) return
        val dm = resources.displayMetrics
        val w = minOf(dp(460), (dm.widthPixels * 0.62f).toInt())
        val h = minOf(dp(300), (dm.heightPixels * 0.78f).toInt())
        val grey = Color.parseColor("#9AA7C0")

        val lp = WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START; x = dp(70); y = dp(16)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        }
        fun relayout() { gview?.let { v -> runCatching { wm.updateViewLayout(v, lp) } } }

        val prog = android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progress = 0
            progressTintList = android.content.res.ColorStateList.valueOf(blue)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.TRANSPARENT)
        }
        val web = android.webkit.WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.setSupportZoom(true)
            settings.builtInZoomControls = true
            settings.displayZoomControls = false
            webViewClient = android.webkit.WebViewClient()
            webChromeClient = object : android.webkit.WebChromeClient() {
                override fun onProgressChanged(view: android.webkit.WebView?, p: Int) {
                    prog.progress = p
                    prog.visibility = if (p in 1..99) View.VISIBLE else View.INVISIBLE
                }
            }
            loadUrl("https://www.google.com")
        }

        fun btn(txt: String, size: Float = 15f, onClick: () -> Unit) = TextView(this).apply {
            text = txt; textSize = size; gravity = Gravity.CENTER; setTextColor(grey)
            setPadding(dp(9), dp(3), dp(9), dp(3)); setOnClickListener { onClick() }
        }
        val alphas = floatArrayOf(1f, 0.75f, 0.5f)
        var ai = 0
        val back = btn("◀") { if (web.canGoBack()) web.goBack() }
        val reload = btn("⟳", 17f) { web.reload() }
        val home = btn("⌂", 17f) { web.loadUrl("https://www.google.com") }
        val fade = btn("◐", 16f) { ai = (ai + 1) % alphas.size; lp.alpha = alphas[ai]; relayout() }
        val close = btn("✕", 16f) { closeGoogle() }

        val title = TextView(this).apply { text = "GOOGLE"; textSize = 11f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(2), dp(2), dp(2))
            addView(title, lay(0, WRAP, 1f))
            addView(back); addView(reload); addView(home); addView(fade); addView(close)
        }
        val grip = TextView(this).apply {
            text = "◢"; textSize = 14f; setTextColor(grey); setPadding(dp(16), dp(4), dp(8), dp(4))
        }
        val footer = LinearLayout(this).apply { gravity = Gravity.END; addView(grip) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.argb(245, 11, 17, 28), Color.argb(110, 47, 128, 255), 14f * d)
            clipToOutline = true
            addView(bar, lay(MATCH, WRAP))
            addView(prog, lay(MATCH, dp(2)))
            addView(web, lay(MATCH, 0, 1f))
            addView(footer, lay(MATCH, WRAP))
        }

        // geser jendela lewat bar judul
        bar.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                    MotionEvent.ACTION_MOVE -> { lp.x = sx + (e.rawX - tx).toInt(); lp.y = sy + (e.rawY - ty).toInt(); relayout() }
                }
                return true
            }
        })
        // ubah ukuran lewat pegangan di pojok kanan bawah
        grip.setOnTouchListener(object : View.OnTouchListener {
            var sw = 0; var sh = 0; var tx = 0f; var ty = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sw = lp.width; sh = lp.height; tx = e.rawX; ty = e.rawY }
                    MotionEvent.ACTION_MOVE -> {
                        lp.width = (sw + (e.rawX - tx).toInt()).coerceIn(dp(240), dm.widthPixels)
                        lp.height = (sh + (e.rawY - ty).toInt()).coerceIn(dp(170), dm.heightPixels)
                        relayout()
                    }
                }
                return true
            }
        })
        // keyboard baru aktif saat isi halaman disentuh, supaya sentuhan di luar jendela tetap ke game
        web.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN && (lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) != 0) {
                lp.flags = lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
                relayout()
            }
            false
        }

        wm.addView(root, lp)
        gview = root; gweb = web
    }

    private fun closeGoogle() {
        val v = gview
        val web = gweb
        gview = null; gweb = null
        v?.let { runCatching { wm.removeView(it) }; it.removeAllViews() }
        web?.let { runCatching { it.stopLoading(); it.destroy() } }
    }

    private fun applyBubbleAlpha() {
        bubble?.alpha = when (bubbleMode) { 0 -> 1f; 1 -> 0.3f; else -> 0f }
    }

    /** Tombol V: normal -> samar -> tak terlihat (tetap bisa disentuh di posisinya). */
    private fun cycleBubble() {
        bubbleMode = (bubbleMode + 1) % 3
        applyBubbleAlpha(); refreshNow()
        Toast.makeText(this, when (bubbleMode) {
            1 -> "Tombol disamarkan"
            2 -> "Tombol tak terlihat. Sentuh posisi tombol tadi, atau pakai notifikasi \"Tampilkan tombol\""
            else -> "Tombol normal"
        }, Toast.LENGTH_LONG).show()
    }

    private fun toggleDnd() {
        val nm = getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) {
            closeGenie()
            Toast.makeText(this, "Izinkan akses Jangan Ganggu untuk VANX", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        }
        val on = nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_ALL
        nm.setInterruptionFilter(if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY else NotificationManager.INTERRUPTION_FILTER_ALL)
        refreshNow()
    }

    private fun toggleAwake() {
        awake = !awake
        hudLp.flags = if (awake) hudLp.flags or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        else hudLp.flags and WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON.inv()
        hud?.let { wm.updateViewLayout(it, hudLp) }
        Toast.makeText(this, if (awake) "Layar tetap menyala" else "Layar normal", Toast.LENGTH_SHORT).show()
    }

    private fun cleanRam() {
        Toast.makeText(this, "Membersihkan RAM...", Toast.LENGTH_SHORT).show()
        val keep = GameSessionService.state.value?.pkg
        scope.launch {
            val r = runBoost(this@FloatingService, Profile(clean = true), keep, store)
            handler.post {
                val msg = r.freedMb?.let { "RAM bebas berubah " + (if (it >= 0) "+" else "") + it + " MB" } ?: "Selesai"
                Toast.makeText(this@FloatingService, msg, Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun setShown(b: Boolean) { handler.post { shown = b; applyVis() } }

    private fun applyVis() {
        bubble?.visibility = if (shown) View.VISIBLE else View.INVISIBLE
        gview?.visibility = if (shown) View.VISIBLE else View.INVISIBLE
        hud?.visibility = if (shown && hudOn) View.VISIBLE else View.INVISIBLE
        cross?.visibility = if (shown && (cross?.shape ?: 0) != 0) View.VISIBLE else View.INVISIBLE
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        closeGenie()
        closeGoogle()
        listOf(bubble, hud, cross).forEach { v -> v?.let { runCatching { wm.removeView(it) } } }
        bubble = null; hud = null; cross = null
        scope.cancel()
        if (FpsService.active.value) FpsService.stop(this)
        instance = null; running.value = false
        super.onDestroy()
    }
}
