package com.vanz.vanxboost

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.Display
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import kotlinx.coroutines.flow.MutableStateFlow

/** Activity transparan: minta izin tangkap layar ke sistem, lalu serahkan ke CaptureService. */
class CaptureActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val mode = intent.getStringExtra("mode") ?: "SHOT"
        val launcher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val data = r.data
            if (r.resultCode == RESULT_OK && data != null) CaptureService.start(this, mode, r.resultCode, data)
            finish()
        }
        launcher.launch(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent())
    }
}

/** Screenshot dan rekam layar lewat MediaProjection; hasil disimpan ke Pictures/VANX dan Movies/VANX. */
class CaptureService : Service() {
    companion object {
        val recording = MutableStateFlow(false)
        fun start(c: Context, mode: String, rc: Int, data: Intent) {
            c.startForegroundService(Intent(c, CaptureService::class.java).putExtra("mode", mode).putExtra("rc", rc).putExtra("data", data))
        }
        fun stop(c: Context) { c.stopService(Intent(c, CaptureService::class.java)) }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var rec: MediaRecorder? = null
    private var pfd: ParcelFileDescriptor? = null
    private var uri: Uri? = null
    private var isRec = false
    private val cb = object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i == null || i.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        val mode = i.getStringExtra("mode") ?: "SHOT"
        isRec = mode == "REC"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("vanx_cap", "Screenshot dan rekam", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 2, Intent(this, CaptureService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        startForeground(
            3,
            Notification.Builder(this, "vanx_cap").setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle(if (isRec) "VANX sedang merekam layar" else "VANX mengambil screenshot")
                .addAction(Notification.Action.Builder(null, "Berhenti", stop).build()).build(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        )
        @Suppress("DEPRECATION") val data = i.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        try {
            val mp = getSystemService(MediaProjectionManager::class.java).getMediaProjection(i.getIntExtra("rc", 0), data)
            projection = mp
            mp.registerCallback(cb, handler)
            if (isRec) record(mp) else shot(mp)
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun dims(): Triple<Int, Int, Int> {
        val dm = DisplayMetrics()
        getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(dm)
        return Triple(dm.widthPixels, dm.heightPixels, dm.densityDpi)
    }

    private fun shot(mp: MediaProjection) {
        val (w, h, dpi) = dims()
        FloatingService.instance?.setShown(false)
        handler.postDelayed({
            val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
            reader = r
            vd = mp.createVirtualDisplay("vanx_shot", w, h, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler)
            var done = false
            r.setOnImageAvailableListener({ rd ->
                if (done) return@setOnImageAvailableListener
                val img = rd.acquireLatestImage() ?: return@setOnImageAvailableListener
                done = true
                try { save(img, w, h) } finally { img.close() }
                stopSelf()
            }, handler)
        }, 450)
    }

    private fun save(img: Image, w: Int, h: Int) {
        val pl = img.planes[0]
        val rowPad = pl.rowStride - pl.pixelStride * w
        val raw = Bitmap.createBitmap(w + rowPad / pl.pixelStride, h, Bitmap.Config.ARGB_8888)
        raw.copyPixelsFromBuffer(pl.buffer)
        val bmp = Bitmap.createBitmap(raw, 0, 0, w, h)
        val cv = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "VANX_${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/VANX")
        }
        val u = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
        u?.let { contentResolver.openOutputStream(it)?.use { o -> bmp.compress(Bitmap.CompressFormat.PNG, 100, o) } }
        Toast.makeText(this, "Screenshot tersimpan di Pictures/VANX", Toast.LENGTH_SHORT).show()
    }

    @Suppress("DEPRECATION")
    private fun record(mp: MediaProjection) {
        val (w0, h0, dpi) = dims()
        val k = minOf(1f, 1080f / minOf(w0, h0))
        val w = (w0 * k).toInt() / 2 * 2
        val h = (h0 * k).toInt() / 2 * 2
        val cv = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "VANX_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/VANX")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)
        pfd = contentResolver.openFileDescriptor(uri!!, "w")
        val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
        r.setVideoSource(MediaRecorder.VideoSource.SURFACE)
        r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        r.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
        r.setVideoSize(w, h); r.setVideoFrameRate(30); r.setVideoEncodingBitRate(8_000_000)
        r.setOutputFile(pfd!!.fileDescriptor)
        r.prepare()
        rec = r
        vd = mp.createVirtualDisplay("vanx_rec", w, h, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler)
        r.start()
        recording.value = true
        Toast.makeText(this, "Merekam layar...", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        runCatching { rec?.stop() }
        runCatching { rec?.release() }
        vd?.release(); reader?.close()
        runCatching { projection?.unregisterCallback(cb); projection?.stop() }
        runCatching { pfd?.close() }
        if (isRec) uri?.let { u ->
            runCatching { contentResolver.update(u, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null) }
            Toast.makeText(this, "Video tersimpan di Movies/VANX", Toast.LENGTH_SHORT).show()
        }
        recording.value = false
        FloatingService.instance?.setShown(true)
        super.onDestroy()
    }
}
