package com.vanz.vanxboost

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Display
import android.widget.Toast
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * FPS meter tanpa root/Shizuku: mirror layar berukuran kecil lewat MediaProjection,
 * lalu menghitung berapa kali layar diperbarui per detik (hasilnya mendekati FPS game layar penuh).
 */
class FpsService : Service() {
    companion object {
        val fps = MutableStateFlow(0)
        val active = MutableStateFlow(false)
        fun start(c: Context, rc: Int, data: Intent) {
            c.startForegroundService(Intent(c, FpsService::class.java).putExtra("rc", rc).putExtra("data", data))
        }
        fun stop(c: Context) { c.stopService(Intent(c, FpsService::class.java)) }
    }

    private val main = Handler(Looper.getMainLooper())
    private val counter = AtomicInteger(0)
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private val cb = object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }
    private val tick = object : Runnable {
        override fun run() { fps.value = counter.getAndSet(0); main.postDelayed(this, 1000) }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i == null || i.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("vanx_fps", "FPS meter", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 3, Intent(this, FpsService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        startForeground(
            5,
            Notification.Builder(this, "vanx_fps").setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("VANX FPS meter aktif")
                .addAction(Notification.Action.Builder(null, "Matikan", stop).build()).build(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        )
        @Suppress("DEPRECATION") val data = i.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        try {
            val mp = getSystemService(MediaProjectionManager::class.java).getMediaProjection(i.getIntExtra("rc", 0), data)
            projection = mp
            mp.registerCallback(cb, main)
            val th = HandlerThread("vanx-fps")
            th.start()
            thread = th
            val h = Handler(th.looper)
            val (w, hh, dpi) = mirror()
            val r = ImageReader.newInstance(w, hh, PixelFormat.RGBA_8888, 3)
            reader = r
            r.setOnImageAvailableListener({ rd ->
                val img = rd.acquireNextImage()
                if (img != null) { counter.incrementAndGet(); img.close() }
            }, h)
            vd = mp.createVirtualDisplay("vanx_fps", w, hh, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, h)
            active.value = true
            main.post(tick)
        } catch (e: Exception) {
            Toast.makeText(this, "FPS meter gagal: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun mirror(): Triple<Int, Int, Int> {
        val dm = DisplayMetrics()
        getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(dm)
        val k = 160f / maxOf(dm.widthPixels, dm.heightPixels)
        return Triple((dm.widthPixels * k).toInt().coerceAtLeast(16), (dm.heightPixels * k).toInt().coerceAtLeast(16), dm.densityDpi)
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        vd?.release()
        reader?.close()
        runCatching { projection?.unregisterCallback(cb); projection?.stop() }
        thread?.quitSafely()
        active.value = false
        fps.value = 0
        super.onDestroy()
    }
}
