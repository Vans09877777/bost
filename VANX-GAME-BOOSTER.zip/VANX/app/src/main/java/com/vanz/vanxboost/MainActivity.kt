package com.vanz.vanxboost

import android.Manifest
import android.app.Activity
import android.media.projection.MediaProjectionManager
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.res.painterResource
import kotlinx.coroutines.withTimeoutOrNull
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

val Blue = Color(0xFF2F80FF)
val Cyan = Color(0xFF4CC9F0)
val Ink = Color(0xFF04070D)
val PanelBg = Color(0xFF0B111C)
val Dim = Color(0xFF7F8CA3)
private val Cut = CutCornerShape(topStart = 14.dp, bottomEnd = 14.dp)
private val CutSm = CutCornerShape(topStart = 8.dp, bottomEnd = 8.dp)
private val BadgeBrush = Brush.radialGradient(listOf(Color(0xFF1E4FA8), Color(0xFF07122B)))
private val RingBrush = Brush.sweepGradient(listOf(Color.Transparent, Blue, Cyan))
private val VanxScheme = darkColorScheme(
    primary = Blue, secondary = Cyan, background = Ink, surface = PanelBg,
    onBackground = Color.White, onSurface = Color.White, onPrimary = Color.White
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent { MaterialTheme(colorScheme = VanxScheme) { App() } }
    }
}

// ---------- komponen dasar ----------

@Composable
fun Pane(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    var m = modifier.clip(Cut).background(PanelBg).border(1.dp, Color(0x33FFFFFF), Cut)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Column(m.padding(12.dp), content = content)
}

@Composable
fun Tag(t: String) = Row(verticalAlignment = Alignment.CenterVertically) {
    Box(Modifier.size(width = 4.dp, height = 14.dp).background(Blue))
    Text(t, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp, modifier = Modifier.padding(start = 8.dp))
}

@Composable
fun BigButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        modifier.clip(Cut).background(if (enabled) Blue else Color(0xFF1B3A6B))
            .clickable(enabled = enabled, onClick = onClick).padding(vertical = 12.dp),
        Alignment.Center
    ) { Text(text, color = Color.White, fontWeight = FontWeight.Black, letterSpacing = 3.sp, fontSize = 15.sp) }
}

@Composable
fun ModeChip(text: String, sel: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier.clip(CutSm).background(if (sel) Blue else Color(0x22FFFFFF))
            .border(1.dp, if (sel) Blue else Color(0x44FFFFFF), CutSm)
            .clickable(onClick = onClick).padding(vertical = 8.dp),
        Alignment.Center
    ) { Text(text, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp) }
}

@Composable
fun ArcGauge(frac: Float, value: String, label: String, dia: Dp, color: Color = Blue) {
    val a by animateFloatAsState(frac.coerceIn(0f, 1f), tween(600), label = "arc")
    Box(Modifier.size(dia), Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(8.dp)) {
            val st = Stroke(width = 10.dp.toPx())
            drawArc(Color(0xFF23232C), 135f, 270f, false, style = st)
            drawArc(color, 135f, 270f * a, false, style = st)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, color = Color.White, fontSize = (dia.value / 5f).sp, fontWeight = FontWeight.Black)
            Text(label, color = Dim, fontSize = 9.sp, letterSpacing = 2.sp)
        }
    }
}

@Composable
fun Tile(title: String, value: String, sub: String, m: Modifier = Modifier) = Pane(m) {
    Text(title, color = Dim, fontSize = 9.sp, letterSpacing = 2.sp)
    Text(value, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black, maxLines = 1)
    if (sub.isNotEmpty()) Text(sub, color = Blue, fontSize = 9.sp)
}

@Composable
fun NavItem(label: String, icon: ImageVector, sel: Boolean, onClick: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().clickable(onClick = onClick)
            .background(if (sel) Color(0x222F80FF) else Color.Transparent)
            .drawBehind { if (sel) drawRect(Blue, size = Size(3.dp.toPx(), size.height)) }
            .padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label, tint = if (sel) Blue else Dim)
        Text(label, color = if (sel) Color.White else Dim, fontSize = 8.sp, letterSpacing = 1.sp)
    }
}

@Composable
fun SwitchRow(label: String, v: Boolean, on: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), color = Color.White, fontSize = 12.sp)
        Switch(v, on)
    }
}

@Composable
fun rememberSnap(ms: Long): State<Snap?> {
    val c = LocalContext.current
    return produceState<Snap?>(null, ms) {
        while (true) { value = withContext(Dispatchers.IO) { Sys.snap(c) }; delay(ms) }
    }
}

@Composable
fun AppIcon(pkg: String, size: Dp = 44.dp) {
    val c = LocalContext.current
    val bmp by produceState<ImageBitmap?>(AppCache.icons[pkg], pkg) {
        if (value == null) value = withContext(Dispatchers.IO) {
            runCatching { c.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap() }
                .getOrNull()?.also { AppCache.icons[pkg] = it }
        }
    }
    val b = bmp
    if (b != null) Image(b, null, Modifier.size(size).clip(RoundedCornerShape(10.dp)))
    else Box(Modifier.size(size).background(Color(0x22FFFFFF), RoundedCornerShape(10.dp)))
}

@Composable
fun ProfileForm(p: Profile, showGfx: Boolean = false, onChange: (Profile) -> Unit) {
    Column {
        Text("MODE PERFORMA", color = Blue, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 2.sp)
        listOf(
            "BALANCED" to "Balanced: monitor tiap 2 dtk",
            "PERFORMANCE" to "Turbo: monitor tiap 5 dtk, animasi minim",
            "BATTERY" to "Saver: monitor tiap 10 dtk, hemat daya"
        ).forEach { (k, l) ->
            Row(Modifier.fillMaxWidth().clickable { onChange(p.copy(mode = k)) }, verticalAlignment = Alignment.CenterVertically) {
                RadioButton(p.mode == k, { onChange(p.copy(mode = k)) })
                Text(l, fontSize = 12.sp, color = Color.White)
            }
        }
        if (showGfx) {
            Text("PRESET GRAFIK", color = Blue, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 2.sp, modifier = Modifier.padding(top = 8.dp))
            listOf("NORMAL" to "Normal", "HEMAT" to "Hemat (grafik sedang)", "BURIK" to "Burik (grafik terendah, FPS maksimal)").forEach { (k, l) ->
                Row(Modifier.fillMaxWidth().clickable { onChange(p.copy(gfx = k)) }, verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(p.gfx == k, { onChange(p.copy(gfx = k)) })
                    Text(l, fontSize = 12.sp, color = Color.White)
                }
            }
        }
        SwitchRow("Jangan Ganggu saat bermain", p.dnd) { onChange(p.copy(dnd = it)) }
        SwitchRow("Bersihkan proses latar", p.clean) { onChange(p.copy(clean = it)) }
        SwitchRow("Game Genie panel saat bermain", p.overlay) { onChange(p.copy(overlay = it)) }
        Text("Peringatan panas di ${p.warnC}°C", color = Color.White, fontSize = 12.sp)
        Slider(p.warnC.toFloat(), { onChange(p.copy(warnC = it.toInt())) }, valueRange = 36f..50f)
    }
}

@Composable
fun ProfileDialog(title: String, init: Profile, onSave: (Profile) -> Unit, onDismiss: () -> Unit) {
    var p by remember { mutableStateOf(init) }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = PanelBg,
        title = { Text("Profil: $title") },
        text = { Column(Modifier.verticalScroll(rememberScrollState())) { ProfileForm(p, true) { p = it } } },
        confirmButton = { TextButton({ onSave(p) }) { Text("Simpan") } },
        dismissButton = { TextButton(onDismiss) { Text("Batal") } }
    )
}

// ---------- root ----------

@Composable
fun App() {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    LaunchedEffect(Unit) { AppCache.get(ctx) }
    var splash by remember { mutableStateOf(true) }
    var tab by remember { mutableIntStateOf(0) }
    var launching by remember { mutableStateOf<AppItem?>(null) }
    val tabs = listOf(
        "HOME" to Icons.Default.Home, "GAMES" to Icons.Default.PlayArrow, "BOOST" to Icons.Default.Build,
        "MONITOR" to Icons.Default.Info, "SETTING" to Icons.Default.Settings
    )
    Box(Modifier.fillMaxSize().background(Ink)) {
        Row(Modifier.fillMaxSize()) {
            Column(
                Modifier.width(80.dp).fillMaxHeight().background(Color(0xFF070B14)).verticalScroll(rememberScrollState()).padding(top = 8.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp), horizontalAlignment = Alignment.CenterHorizontally
            ) {
                LogoBadge(50.dp)
                Spacer(Modifier.height(6.dp))
                tabs.forEachIndexed { i, (n, ic) -> NavItem(n, ic, tab == i) { tab = i } }
            }
            Box(Modifier.weight(1f).fillMaxHeight()) {
                when (tab) {
                    0 -> Home(store, { tab = 1 }) { launching = it }
                    1 -> Games(store) { launching = it }
                    2 -> Booster(store)
                    3 -> Monitor(store)
                    else -> SettingsScreen(store)
                }
            }
        }
        launching?.let { LaunchScreen(it, store) { launching = null } }
        if (splash) SplashScreen(store) { splash = false }
    }
}

// ---------- Home ----------

@Composable
fun GameCard(a: AppItem, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(Cut).background(PanelBg).border(1.dp, Color(0x552F80FF), Cut).clickable(onClick = onClick).padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.weight(1f), Alignment.Center) { AppIcon(a.pkg, 72.dp) }
        Text(a.label.uppercase(), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, textAlign = TextAlign.Center)
        Box(Modifier.fillMaxWidth().padding(top = 6.dp).clip(CutSm).background(Blue).padding(vertical = 6.dp), Alignment.Center) {
            Text("PLAY", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
        }
    }
}

@Composable
fun Home(store: Store, goGames: () -> Unit, onLaunch: (AppItem) -> Unit) {
    val c = LocalContext.current
    val scope = rememberCoroutineScope()
    var mode by remember { mutableStateOf(store.profile("_global").mode) }
    val s by rememberSnap(pollMs(mode))
    val sess by GameSessionService.state.collectAsState()
    val floating by FloatingService.running.collectAsState()
    var res by remember { mutableStateOf<BoostResult?>(null) }
    var busy by remember { mutableStateOf(false) }
    var games by remember { mutableStateOf(listOf<AppItem>()) }
    val elapsed by produceState(0L) {
        while (true) { value = GameSessionService.state.value?.let { (SystemClock.elapsedRealtime() - it.startMs) / 1000 } ?: 0L; delay(1000) }
    }
    LaunchedEffect(Unit) {
        val lib = store.library()
        val favs = store.favorites()
        games = AppCache.get(c).filter { it.pkg in lib || it.pkg in favs }.sortedByDescending { it.pkg in favs }
    }
    fun boost() {
        if (busy) return
        busy = true
        scope.launch { res = runBoost(c, store.profile("_global"), null, store); busy = false }
    }
    val x = s
    val z = sess
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Column {
                Text("VANX GAME BOOSTER PRO", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                Text("v1.0.0", color = Blue, fontSize = 10.sp, letterSpacing = 2.sp)
            }
            Spacer(Modifier.weight(1f))
            if (z != null) {
                Text("${z.label.uppercase()}  %d:%02d:%02d".format(elapsed / 3600, elapsed % 3600 / 60, elapsed % 60), color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                TextButton({ GameSessionService.stop(c) }) { Text("STOP", color = Blue, fontSize = 11.sp) }
            }
            if (x != null) {
                Text("%.0f°C".format(x.batTempC), color = if (x.batTempC >= 42) Blue else Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text("${x.batPct}%", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(x.net.uppercase(), color = Dim, fontSize = 11.sp)
            }
        }
        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(Modifier.weight(1.15f).fillMaxHeight()) {
                Tag("MY GAMES")
                Spacer(Modifier.height(6.dp))
                if (games.isEmpty()) Pane(Modifier.weight(1f).fillMaxWidth(), onClick = goGames) {
                    Text("+ TAMBAH GAME", color = Blue, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                    Text("Buka tab GAMES, lalu tekan + pada game kamu.", color = Dim, fontSize = 11.sp)
                } else LazyRow(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(games, key = { it.pkg }) { g -> GameCard(g, Modifier.width(118.dp).fillMaxHeight()) { onLaunch(g) } }
                }
            }
            Column(Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val pct = if (x == null) 0f else x.ramUsedMb.toFloat() / x.ramTotalMb.coerceAtLeast(1)
                Pane(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ArcGauge(pct, "${(pct * 100).toInt()}%", if (busy) "BOOSTING" else "RAM", 118.dp)
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                listOf("BALANCED" to "BAL", "PERFORMANCE" to "TURBO", "BATTERY" to "SAVER").forEach { (k, l) ->
                                    ModeChip(l, mode == k, Modifier.weight(1f)) {
                                        mode = k
                                        store.saveProfile("_global", store.profile("_global").copy(mode = k))
                                        if (k == "PERFORMANCE") store.minAnim = true
                                    }
                                }
                            }
                            BigButton(if (busy) "..." else "BOOST", Modifier.fillMaxWidth(), !busy) { boost() }
                        }
                    }
                }
                if (x != null) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Tile("TEMP", "%.1f°C".format(x.batTempC), Sys.thermalLabel(x.thermal).uppercase(), Modifier.weight(1f))
                    Tile("RAM FREE", "${x.ramAvailMb} MB", "", Modifier.weight(1f))
                }
                Pane(Modifier.fillMaxWidth()) {
                    SwitchRow("GAME GENIE PANEL (floating)", floating) { on ->
                        if (!on) FloatingService.stop(c)
                        else if (Settings.canDrawOverlays(c)) FloatingService.start(c)
                        else c.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${c.packageName}")))
                    }
                }
                res?.let { r ->
                    Pane(Modifier.fillMaxWidth()) {
                        r.lines.forEach { Text("> $it", color = Cyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(vertical = 1.dp)) }
                    }
                }
            }
        }
    }
}

// ---------- Games ----------

@Composable
fun LibCard(a: AppItem, inLib: Boolean, fav: Boolean, onPlay: () -> Unit, onFav: () -> Unit, onProfile: () -> Unit, onToggle: () -> Unit) {
    Column(
        Modifier.clip(Cut).background(PanelBg).border(1.dp, if (inLib) Color(0x662F80FF) else Color(0x22FFFFFF), Cut).padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AppIcon(a.pkg, 56.dp)
        Text(a.label.uppercase(), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.padding(top = 4.dp))
        Box(Modifier.fillMaxWidth().padding(top = 6.dp).clip(CutSm).background(Blue).clickable(onClick = onPlay).padding(vertical = 6.dp), Alignment.Center) {
            Text("PLAY", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            IconButton(onFav, Modifier.size(30.dp)) { Icon(Icons.Default.Star, "Favorit", tint = if (fav) Cyan else Dim) }
            IconButton(onProfile, Modifier.size(30.dp)) { Icon(Icons.Default.Settings, "Profil", tint = Dim) }
            IconButton(onToggle, Modifier.size(30.dp)) {
                if (inLib) Icon(Icons.Default.Delete, "Hapus dari library", tint = Dim) else Icon(Icons.Default.Add, "Tambah ke library", tint = Dim)
            }
        }
    }
}

@Composable
fun Games(store: Store, onLaunch: (AppItem) -> Unit) {
    val c = LocalContext.current
    var apps by remember { mutableStateOf<List<AppItem>?>(AppCache.apps) }
    var lib by remember { mutableStateOf(store.library()) }
    var favs by remember { mutableStateOf(store.favorites()) }
    var q by remember { mutableStateOf("") }
    var tab by remember { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf<AppItem?>(null) }
    LaunchedEffect(Unit) { apps = AppCache.get(c) }
    fun toggleLib(pkg: String) { lib = if (pkg in lib) lib - pkg else lib + pkg; store.setLibrary(lib) }
    fun toggleFav(pkg: String) { favs = if (pkg in favs) favs - pkg else favs + pkg; store.setFavorites(favs) }
    val f = (apps ?: emptyList()).filter { it.label.contains(q, true) || it.pkg.contains(q, true) }
    val list = when (tab) {
        0 -> f.filter { it.isGame || it.pkg in lib }.sortedWith(compareByDescending<AppItem> { it.pkg in favs }.thenByDescending { it.pkg in lib })
        1 -> f.filter { it.pkg in favs }
        else -> f.filter { !it.isGame && it.pkg !in lib }
    }
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tag("GAMES")
            OutlinedTextField(q, { q = it }, Modifier.weight(1f), label = { Text("Cari game atau aplikasi") }, singleLine = true)
            ModeChip("GAMES", tab == 0, Modifier.width(76.dp)) { tab = 0 }
            ModeChip("FAVORIT", tab == 1, Modifier.width(76.dp)) { tab = 1 }
            ModeChip("APPS", tab == 2, Modifier.width(76.dp)) { tab = 2 }
        }
        if (apps == null) Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = Blue) }
        else if (list.isEmpty()) Text(if (tab == 1) "Belum ada favorit. Tekan bintang pada game." else "Tidak ada hasil.", color = Dim, fontSize = 12.sp)
        else LazyVerticalGrid(
            columns = GridCells.Adaptive(140.dp), modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(list, key = { it.pkg }) { a ->
                LibCard(a, a.pkg in lib, a.pkg in favs, { onLaunch(a) }, { toggleFav(a.pkg) }, { editing = a }, { toggleLib(a.pkg) })
            }
        }
    }
    editing?.let { a ->
        ProfileDialog(a.label, store.profile(a.pkg), { store.saveProfile(a.pkg, it); editing = null }, { editing = null })
    }
}

// ---------- Booster ----------

@Composable
fun Booster(store: Store) {
    val c = LocalContext.current
    val scope = rememberCoroutineScope()
    var p by remember { mutableStateOf(store.profile("_global")) }
    var res by remember { mutableStateOf<BoostResult?>(null) }
    var busy by remember { mutableStateOf(false) }
    var minAnim by remember { mutableStateOf(store.minAnim) }
    Row(Modifier.fillMaxSize().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Tag("PERFORMANCE PROFILE")
            Pane(Modifier.fillMaxWidth()) {
                ProfileForm(p) { p = it; store.saveProfile("_global", it) }
                SwitchRow("Mode minim animasi", minAnim) { minAnim = it; store.minAnim = it }
            }
        }
        Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Tag("SYSTEM BOOST")
            BigButton(if (busy) "ANALYZING..." else "BOOST NOW", Modifier.fillMaxWidth(), !busy) {
                busy = true
                scope.launch { res = runBoost(c, p, null, store); minAnim = store.minAnim; busy = false }
            }
            Pane(Modifier.fillMaxWidth().weight(1f)) {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    val r = res
                    if (r == null) Text("Tekan BOOST NOW untuk menganalisis dan mengoptimalkan perangkat.", color = Dim, fontSize = 12.sp)
                    else r.lines.forEach { Text("> $it", color = Cyan, fontSize = 11.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(vertical = 2.dp)) }
                }
            }
        }
    }
}

// ---------- Monitor ----------

@Composable
fun rememberOwnFps(): State<Int> {
    val fps = remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        var frames = 0; var t0 = 0L
        while (true) {
            val t = withFrameNanosCompat()
            if (t0 == 0L) t0 = t
            frames++
            if (t - t0 >= 1_000_000_000L) { fps.intValue = frames; frames = 0; t0 = t }
        }
    }
    return fps
}

private suspend fun withFrameNanosCompat(): Long = androidx.compose.runtime.withFrameNanos { it }

@Composable
fun GaugeCell(title: String, frac: Float, value: String, sub: String, color: Color, m: Modifier) = Pane(m) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        ArcGauge(frac, value, title, 104.dp, color)
        Text(sub, color = Dim, fontSize = 9.sp, maxLines = 1)
    }
}

@Composable
fun Monitor(store: Store) {
    val s by rememberSnap(1000L)
    val fps by rememberOwnFps()
    val meter = remember { CpuMeter() }
    val cpu by produceState(0f) { while (true) { delay(1000); value = meter.pct() } }
    val x = s
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Tag("PERFORMANCE MONITOR")
        if (x == null) { CircularProgressIndicator(color = Blue); return@Column }
        val hot = x.batTempC >= store.profile("_global").warnC || x.thermal >= 3
        val ramF = x.ramUsedMb.toFloat() / x.ramTotalMb.coerceAtLeast(1)
        val stoF = x.storUsedGb / x.storTotalGb.coerceAtLeast(1f)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GaugeCell("RAM", ramF, "${(ramF * 100).toInt()}%", "${x.ramUsedMb}/${x.ramTotalMb} MB", Blue, Modifier.weight(1f))
            GaugeCell("TEMP", (x.batTempC - 20f) / 40f, "%.0f°C".format(x.batTempC), "THERMAL ${Sys.thermalLabel(x.thermal).uppercase()}", if (hot) Blue else Cyan, Modifier.weight(1f))
            GaugeCell("BATTERY", x.batPct / 100f, "${x.batPct}%", if (x.charging) "CHARGING" else "ON BATTERY", Cyan, Modifier.weight(1f))
            GaugeCell("STORAGE", stoF, "%.0f%%".format(stoF * 100f), "%.0f / %.0f GB".format(x.storUsedGb, x.storTotalGb), Cyan, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Tile("REFRESH RATE", "$fps Hz", "", Modifier.weight(1f))
            Tile("THERMAL HEADROOM", if (x.headroom.isNaN()) "N/A" else "%.2f".format(x.headroom), "", Modifier.weight(1f))
            Tile("NETWORK", x.net, "", Modifier.weight(1f))
            Tile("CPU (APP)", "%.1f%%".format(cpu), "", Modifier.weight(1f))
        }
    }
}

// ---------- Settings ----------

@Composable
fun PermRow(label: String, ok: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("$label: ${if (ok) "AKTIF" else "BELUM"}", Modifier.weight(1f), color = if (ok) Cyan else Color.White, fontSize = 13.sp)
        Button(onClick) { Text("ATUR") }
    }
}

@Composable
fun SettingsScreen(store: Store) {
    val c = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(o)
        onDispose { owner.lifecycle.removeObserver(o) }
    }
    val overlayOk = remember(tick) { Settings.canDrawOverlays(c) }
    val dndOk = remember(tick) { c.getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted }
    var soundOn by remember { mutableStateOf(store.soundOn) }
    var vol by remember { mutableFloatStateOf(store.volume) }
    var fpsAuto by remember { mutableStateOf(store.fpsAuto) }
    Row(Modifier.fillMaxSize().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Tag("SOUND")
            Pane(Modifier.fillMaxWidth()) {
                SwitchRow("Suara mesin V8 (splash dan loading)", soundOn) { soundOn = it; store.soundOn = it }
                Text("Volume ${(vol * 100).toInt()}%", color = Color.White, fontSize = 12.sp)
                Slider(vol, { vol = it; store.volume = it }, valueRange = 0f..1f)
                OutlinedButton(onClick = { SoundFx.play(c, store, "start") }) { Text("TES SUARA") }
            }
            Tag("FLOATING")
            Pane(Modifier.fillMaxWidth()) {
                SwitchRow("FPS langsung tampil saat floating menyala (izin rekam layar diminta sekali)", fpsAuto) { fpsAuto = it; store.fpsAuto = it }
            }
            Tag("PERMISSIONS")
            Pane(Modifier.fillMaxWidth()) {
                PermRow("Tampil di atas aplikasi lain", overlayOk) {
                    c.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${c.packageName}")))
                }
                PermRow("Jangan Ganggu", dndOk) { c.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
            }
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Tag("ABOUT")
            Pane(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    LogoBadge(72.dp)
                    Column {
                        Text("VANX GAME BOOSTER PRO", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("v1.0.0", color = Blue, fontSize = 12.sp)
                        Text("Developer: VANZ", color = Dim, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

// ---------- Loading screen ----------

@Composable
fun LaunchScreen(a: AppItem, store: Store, onClose: () -> Unit) {
    val c = LocalContext.current
    val p = remember { store.profile(a.pkg) }
    val tips = remember { gfxTips(a.pkg, p.gfx) }
    var lines by remember { mutableStateOf(listOf<String>()) }
    var err by remember { mutableStateOf<String?>(null) }
    var prog by remember { mutableFloatStateOf(0f) }
    var tick by remember { mutableIntStateOf(0) }
    var stage by remember { mutableStateOf("ANALYZING DEVICE") }
    var consent by remember { mutableIntStateOf(0) }
    val projLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val d = r.data
        if (r.resultCode == Activity.RESULT_OK && d != null) FpsService.start(c, r.resultCode, d)
        consent = 2
    }
    val inf = rememberInfiniteTransition(label = "inf")
    val spin by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(2400, easing = LinearEasing)), label = "spin")
    val pulse by inf.animateFloat(0.94f, 1.06f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    val scan by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2000, easing = LinearEasing)), label = "scan")
    BackHandler { SoundFx.stop(); onClose() }
    DisposableEffect(Unit) { onDispose { SoundFx.stop() } }
    LaunchedEffect(a.pkg) {
        SoundFx.play(c, store, "play")
        if (p.overlay && store.fpsAuto && !FpsService.active.value && Settings.canDrawOverlays(c)) {
            consent = 1
            projLauncher.launch(c.getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent())
        }
        val total = 5500L
        val t0 = SystemClock.elapsedRealtime()
        val r = withTimeoutOrNull(3500L) { runBoost(c, p.effective(), a.pkg, store) }
            ?: BoostResult(listOf("Analisis dilewati (waktu habis)"), null)
        while (true) {
            val el = SystemClock.elapsedRealtime() - t0
            val f = (el / total.toFloat()).coerceIn(0f, 1f)
            prog = f
            tick = (el / 160).toInt()
            val want = (f * (r.lines.size + 1)).toInt().coerceAtMost(r.lines.size)
            if (want > lines.size) lines = r.lines.take(want)
            stage = if (f < 0.35f) "ANALYZING DEVICE" else if (f < 0.85f) "OPTIMIZING" else "READY TO PLAY"
            if (el >= total) break
            delay(60)
        }
        lines = r.lines
        var waited = 0
        while (consent == 1 && waited < 12000) { delay(100); waited += 100 }
        val intent = c.packageManager.getLaunchIntentForPackage(a.pkg)
        if (intent == null) { err = "Game tidak bisa dibuka: tidak ada activity peluncur."; return@LaunchedEffect }
        try {
            GameSessionService.start(c, a.pkg, a.label)
            c.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            onClose()
        } catch (e: Exception) {
            GameSessionService.stop(c); err = "Gagal membuka game: ${e.message}"
        }
    }
    Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xFF071A3A), Ink, Color(0xFF05101F)))).pointerInput(Unit) {}) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width; val h = size.height
            val sx = scan * w; val band = 80.dp.toPx()
            drawRect(
                Brush.horizontalGradient(listOf(Color.Transparent, Blue.copy(alpha = 0.16f), Color.Transparent), startX = sx - band, endX = sx + band),
                topLeft = Offset(sx - band, 0f), size = Size(band * 2, h)
            )
            val m = 16.dp.toPx(); val len = 30.dp.toPx(); val sw = 2.dp.toPx()
            fun corner(cx: Float, cy: Float, dx: Float, dy: Float) {
                drawLine(Blue, Offset(cx, cy), Offset(cx + dx * len, cy), sw)
                drawLine(Blue, Offset(cx, cy), Offset(cx, cy + dy * len), sw)
            }
            corner(m, m, 1f, 1f); corner(w - m, m, -1f, 1f); corner(m, h - m, 1f, -1f); corner(w - m, h - m, -1f, -1f)
        }
        Image(painterResource(R.drawable.vanx_logo), null, Modifier.align(Alignment.TopEnd).padding(14.dp).size(42.dp))
        Row(
            Modifier.fillMaxSize().padding(horizontal = 40.dp, vertical = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(32.dp), verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(210.dp), Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val rr = size.minDimension / 2f
                    rotate(spin) { drawArc(brush = RingBrush, startAngle = 0f, sweepAngle = 110f, useCenter = false, style = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round)) }
                    drawCircle(Blue.copy(alpha = 0.10f), radius = rr * 0.55f * pulse)
                    drawBolts(tick, Offset(size.width / 2f, size.height / 2f), rr * 0.62f, rr * 0.96f, 4, Cyan)
                }
                Box(Modifier.scale(pulse)) { AppIcon(a.pkg, 88.dp) }
            }
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                Text(a.label.uppercase(), color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp, maxLines = 1)
                Text(stage, color = Blue, fontSize = 12.sp, letterSpacing = 4.sp, modifier = Modifier.padding(top = 2.dp))
                Text("${(prog * 100).toInt()}%", color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.Black)
                Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    val on = (prog * 24).toInt()
                    repeat(24) { i ->
                        Box(Modifier.weight(1f).height(10.dp).background(if (i < on) Blue else Color(0x22FFFFFF), CutCornerShape(topStart = 3.dp, bottomEnd = 3.dp)))
                    }
                }
                lines.takeLast(5).forEach {
                    Text("> $it", color = Color(0xFFB8DFFF), fontSize = 11.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.fillMaxWidth().padding(vertical = 1.dp))
                }
                if (tips.isNotEmpty()) Pane(Modifier.fillMaxWidth().padding(top = 10.dp)) {
                    Text("SETEL DI DALAM GAME (${p.gfx})", color = Blue, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    tips.forEach { Text("• $it", color = Color.White, fontSize = 11.sp) }
                }
                err?.let {
                    Text(it, color = Color(0xFFFF5252), modifier = Modifier.padding(top = 10.dp))
                    Button({ SoundFx.stop(); onClose() }, Modifier.padding(top = 6.dp)) { Text("Kembali") }
                }
            }
        }
    }
}

object AppCache {
    @Volatile var apps: List<AppItem>? = null
    val icons = java.util.concurrent.ConcurrentHashMap<String, ImageBitmap>()
    suspend fun get(c: android.content.Context): List<AppItem> {
        apps?.let { return it }
        val r = withContext(Dispatchers.IO) { scanApps(c.applicationContext) }
        apps = r
        return r
    }
}

@Composable
fun LogoBadge(size: Dp) {
    Box(Modifier.size(size).background(BadgeBrush, CircleShape), Alignment.Center) {
        Image(painterResource(R.drawable.vanx_logo), null, Modifier.fillMaxSize().padding(size * 0.06f))
    }
}

/** Petir biru bergerigi; seed berubah tiap ~160 ms supaya terlihat menyambar. */
fun DrawScope.drawBolts(seed: Int, center: Offset, r0: Float, r1: Float, count: Int, color: Color) {
    val rnd = java.util.Random(seed * 7919L + 13)
    repeat(count) { k ->
        val ang = (k * 360f / count + rnd.nextFloat() * 50f) * (Math.PI.toFloat() / 180f)
        val len = r1 + rnd.nextFloat() * (r1 * 0.35f)
        val fx = center.x + kotlin.math.cos(ang) * r0
        val fy = center.y + kotlin.math.sin(ang) * r0
        val tx = center.x + kotlin.math.cos(ang) * len
        val ty = center.y + kotlin.math.sin(ang) * len
        val segs = 7
        val path = Path()
        path.moveTo(fx, fy)
        for (i in 1 until segs) {
            val t = i / segs.toFloat()
            path.lineTo(fx + (tx - fx) * t + (rnd.nextFloat() - 0.5f) * 26f, fy + (ty - fy) * t + (rnd.nextFloat() - 0.5f) * 26f)
        }
        path.lineTo(tx, ty)
        drawPath(path, color.copy(alpha = 0.25f), style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawPath(path, color, style = Stroke(width = 1.6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/** Splash 4 detik: logo VANX, petir biru, suara mesin V8. */
@Composable
fun SplashScreen(store: Store, onDone: () -> Unit) {
    val c = LocalContext.current
    val total = 4000L
    var tick by remember { mutableIntStateOf(0) }
    var prog by remember { mutableFloatStateOf(0f) }
    val logoScale by animateFloatAsState(if (prog > 0.02f) 1f else 0.85f, tween(700), label = "logo")
    val inf = rememberInfiniteTransition(label = "sp")
    val glow by inf.animateFloat(0.22f, 0.45f, infiniteRepeatable(tween(1200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "glow")
    val scan by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1800, easing = LinearEasing)), label = "scan")
    DisposableEffect(Unit) { onDispose { SoundFx.stop() } }
    LaunchedEffect(Unit) {
        SoundFx.play(c, store, "start")
        val t0 = SystemClock.elapsedRealtime()
        while (true) {
            val el = SystemClock.elapsedRealtime() - t0
            prog = (el / total.toFloat()).coerceIn(0f, 1f)
            tick = (el / 160).toInt()
            if (el >= total) break
            delay(50)
        }
        onDone()
    }
    Box(Modifier.fillMaxSize().background(Ink).pointerInput(Unit) {}, Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val cy = size.height / 2f - 24.dp.toPx()
            val r = 85.dp.toPx()
            drawCircle(
                Brush.radialGradient(listOf(Blue.copy(alpha = glow), Color.Transparent), center = Offset(cx, cy), radius = r * 2.4f),
                radius = r * 2.4f, center = Offset(cx, cy)
            )
            drawBolts(tick, Offset(cx, cy), r * 0.95f, r * 1.9f, 5, Cyan)
            val x = scan * size.width
            val band = 100.dp.toPx()
            drawRect(
                Brush.horizontalGradient(listOf(Color.Transparent, Blue.copy(alpha = 0.12f), Color.Transparent), startX = x - band, endX = x + band),
                topLeft = Offset(x - band, 0f), size = Size(band * 2, size.height)
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(painterResource(R.drawable.vanx_logo), null, Modifier.size(170.dp).scale(logoScale))
            Spacer(Modifier.height(10.dp))
            Text("VANX GAME BOOSTER PRO", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
            Text("v1.0.0", color = Blue, fontSize = 11.sp, letterSpacing = 3.sp)
            Spacer(Modifier.height(12.dp))
            Box(Modifier.width(220.dp).height(3.dp).background(Color(0x33FFFFFF))) {
                Box(Modifier.fillMaxWidth(prog).fillMaxHeight().background(Blue))
            }
        }
    }
}
