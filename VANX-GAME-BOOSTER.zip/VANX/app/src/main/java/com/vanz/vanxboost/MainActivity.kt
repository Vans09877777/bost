package com.vanz.vanxboost

import android.Manifest
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

val Red = Color(0xFFFF0033)
val Cyan = Color(0xFF00E5FF)
val Ink = Color(0xFF0A0A0E)
val PanelBg = Color(0xFF14141B)
val Dim = Color(0xFF8B90A0)
private val Cut = CutCornerShape(topStart = 14.dp, bottomEnd = 14.dp)
private val CutSm = CutCornerShape(topStart = 8.dp, bottomEnd = 8.dp)
private val RingBrush = Brush.sweepGradient(listOf(Color.Transparent, Red, Cyan))
private val VanxScheme = darkColorScheme(
    primary = Red, secondary = Cyan, background = Ink, surface = PanelBg,
    onBackground = Color.White, onSurface = Color.White, onPrimary = Color.White
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent { MaterialTheme(colorScheme = VanxScheme) { App() } }
    }
}

// ---------- komponen dasar ----------

@Composable
fun Pane(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    var m = modifier.clip(Cut).background(PanelBg).border(1.dp, Color(0x33FFFFFF), Cut)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Column(m.padding(12.dp), content = content)
}

@Composable
fun Tag(t: String) = Row(verticalAlignment = Alignment.CenterVertically) {
    Box(Modifier.size(width = 4.dp, height = 14.dp).background(Red))
    Text(t, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp, modifier = Modifier.padding(start = 8.dp))
}

@Composable
fun BigButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        modifier.clip(Cut).background(if (enabled) Red else Color(0xFF5A0A18))
            .clickable(enabled = enabled, onClick = onClick).padding(vertical = 12.dp),
        Alignment.Center
    ) { Text(text, color = Color.White, fontWeight = FontWeight.Black, letterSpacing = 3.sp, fontSize = 15.sp) }
}

@Composable
fun ModeChip(text: String, sel: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier.clip(CutSm).background(if (sel) Red else Color(0x22FFFFFF))
            .border(1.dp, if (sel) Red else Color(0x44FFFFFF), CutSm)
            .clickable(onClick = onClick).padding(vertical = 8.dp),
        Alignment.Center
    ) { Text(text, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp) }
}

@Composable
fun ArcGauge(frac: Float, value: String, label: String, dia: Dp, color: Color = Red) {
    val a by animateFloatAsState(frac.coerceIn(0f, 1f), tween(600), label = "arc")
    Box(Modifier.size(dia), Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(8.dp)) {
            val st = Stroke(width = 10.dp.toPx())
            drawArc(Color(0xFF23232C), 135f, 270f, false, style = st)
            drawArc(color, 135f, 270f * a, false, style = st)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, color = Color.White, fontSize = (dia.value / 5f).sp, fontWeight = FontWeight.Black)
            Text(label, color = Dim, fontSize = 9.sp, letterSpacing = 2.sp)
        }
    }
}

@Composable
fun Tile(title: String, value: String, sub: String, m: Modifier = Modifier) = Pane(m) {
    Text(title, color = Dim, fontSize = 9.sp, letterSpacing = 2.sp)
    Text(value, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black, maxLines = 1)
    if (sub.isNotEmpty()) Text(sub, color = Red, fontSize = 9.sp)
}

@Composable
fun NavItem(label: String, icon: ImageVector, sel: Boolean, onClick: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().clickable(onClick = onClick)
            .background(if (sel) Color(0x22FF0033) else Color.Transparent)
            .drawBehind { if (sel) drawRect(Red, size = Size(3.dp.toPx(), size.height)) }
            .padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label, tint = if (sel) Red else Dim)
        Text(label, color = if (sel) Color.White else Dim, fontSize = 8.sp, letterSpacing = 1.sp)
    }
}

@Composable
fun SwitchRow(label: String, v: Boolean, on: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), color = Color.White, fontSize = 12.sp)
        Switch(v, on)
    }
}

@Composable
fun rememberSnap(ms: Long): State<Snap?> {
    val c = LocalContext.current
    return produceState<Snap?>(null, ms) {
        while (true) { value = withContext(Dispatchers.IO) { Sys.snap(c) }; delay(ms) }
    }
}

@Composable
fun AppIcon(pkg: String, size: Dp = 44.dp) {
    val c = LocalContext.current
    val bmp by produceState<ImageBitmap?>(AppCache.icons[pkg], pkg) {
        if (value == null) value = withContext(Dispatchers.IO) {
            runCatching { c.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap() }
                .getOrNull()?.also { AppCache.icons[pkg] = it }
        }
    }
    val b = bmp
    if (b != null) Image(b, null, Modifier.size(size).clip(RoundedCornerShape(10.dp)))
    else Box(Modifier.size(size).background(Color(0x22FFFFFF), RoundedCornerShape(10.dp)))
}

@Composable
fun ProfileForm(p: Profile, showGfx: Boolean = false, onChange: (Profile) -> Unit) {
    Column {
        Text("MODE PERFORMA", color = Red, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 2.sp)
        listOf(
            "BALANCED" to "Balanced: monitor tiap 2 dtk",
            "PERFORMANCE" to "Turbo: monitor tiap 5 dtk, animasi minim",
            "BATTERY" to "Saver: monitor tiap 10 dtk, hemat daya"
        ).forEach { (k, l) ->
            Row(Modifier.fillMaxWidth().clickable { onChange(p.copy(mode = k)) }, verticalAlignment = Alignment.CenterVertically) {
                RadioButton(p.mode == k, { onChange(p.copy(mode = k)) })
                Text(l, fontSize = 12.sp, color = Color.White)
            }
        }
        if (showGfx) {
            Text("PRESET GRAFIK", color = Red, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 2.sp, modifier = Modifier.padding(top = 8.dp))
            listOf("NORMAL" to "Normal", "HEMAT" to "Hemat (grafik sedang)", "BURIK" to "Burik (grafik terendah, FPS maksimal)").forEach { (k, l) ->
                Row(Modifier.fillMaxWidth().clickable { onChange(p.copy(gfx = k)) }, verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(p.gfx == k, { onChange(p.copy(gfx = k)) })
                    Text(l, fontSize = 12.sp, color = Color.White)
                }
            }
        }
        SwitchRow("Jangan Ganggu saat bermain", p.dnd) { onChange(p.copy(dnd = it)) }
        SwitchRow("Bersihkan proses latar", p.clean) { onChange(p.copy(clean = it)) }
        SwitchRow("Game Genie panel saat bermain", p.overlay) { onChange(p.copy(overlay = it)) }
        Text("Peringatan panas di ${p.warnC}°C", color = Color.White, fontSize = 12.sp)
        Slider(p.warnC.toFloat(), { onChange(p.copy(warnC = it.toInt())) }, valueRange = 36f..50f)
    }
}

@Composable
fun ProfileDialog(title: String, init: Profile, onSave: (Profile) -> Unit, onDismiss: () -> Unit) {
    var p by remember { mutableStateOf(init) }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = PanelBg,
        title = { Text("Profil: $title") },
        text = { Column(Modifier.verticalScroll(rememberScrollState())) { ProfileForm(p, true) { p = it } } },
        confirmButton = { TextButton({ onSave(p) }) { Text("Simpan") } },
        dismissButton = { TextButton(onDismiss) { Text("Batal") } }
    )
}

// ---------- root ----------

@Composable
fun App() {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    LaunchedEffect(Unit) { AppCache.get(ctx) }
    var tab by remember { mutableIntStateOf(0) }
    var launching by remember { mutableStateOf<AppItem?>(null) }
    val tabs = listOf(
        "HOME" to Icons.Default.Home, "GAMES" to Icons.Default.PlayArrow, "BOOST" to Icons.Default.Build,
        "MONITOR" to Icons.Default.Info, "SETTING" to Icons.Default.Settings
    )
    Box(Modifier.fillMaxSize().background(Ink)) {
        Row(Modifier.fillMaxSize()) {
            Column(
                Modifier.width(76.dp).fillMaxHeight().background(Color(0xFF0F0F14)).verticalScroll(rememberScrollState()).padding(top = 6.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                tabs.forEachIndexed { i, (n, ic) -> NavItem(n, ic, tab == i) { tab = i } }
            }
            Box(Modifier.weight(1f).fillMaxHeight()) {
                when (tab) {
                    0 -> Home(store, { tab = 1 }) { launching = it }
                    1 -> Games(store) { launching = it }
                    2 -> Booster(store)
                    3 -> Monitor(store)
                    else -> SettingsScreen()
                }
            }
        }
        launching?.let { LaunchScreen(it, store) { launching = null } }
    }
}

// ---------- Home ----------

@Composable
fun GameCard(a: AppItem, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(Cut).background(PanelBg).border(1.dp, Color(0x55FF0033), Cut).clickable(onClick = onClick).padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.weight(1f), Alignment.Center) { AppIcon(a.pkg, 72.dp) }
        Text(a.label.uppercase(), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, textAlign = TextAlign.Center)
        Box(Modifier.fillMaxWidth().padding(top = 6.dp).clip(CutSm).background(Red).padding(vertical = 6.dp), Alignment.Center) {
            Text("PLAY", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
        }
    }
}

@Composable
fun Home(store: Store, goGames: () -> Unit, onLaunch: (AppItem) -> Unit) {
    val c = LocalContext.current
    val scope = rememberCoroutineScope()
    var mode by remember { mutableStateOf(store.profile("_global").mode) }
    val s by rememberSnap(pollMs(mode))
    val sess by GameSessionService.state.collectAsState()
    val floating by FloatingService.running.collectAsState()
    var res by remember { mutableStateOf<BoostResult?>(null) }
    var busy by remember { mutableStateOf(false) }
    var games by remember { mutableStateOf(listOf<AppItem>()) }
    val elapsed by produceState(0L) {
        while (true) { value = GameSessionService.state.value?.let { (SystemClock.elapsedRealtime() - it.startMs) / 1000 } ?: 0L; delay(1000) }
    }
    LaunchedEffect(Unit) {
        val lib = store.library()
        games = AppCache.get(c).filter { it.pkg in lib }
    }
    fun boost() {
        if (busy) return
        busy = true
        scope.launch { res = runBoost(c, store.profile("_global"), null, store); busy = false }
    }
    val x = s
    val z = sess
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(
                Modifier.drawBehind {
                    val p = Path()
                    p.moveTo(0f, 0f); p.lineTo(size.width, 0f); p.lineTo(size.width - 18.dp.toPx(), size.height); p.lineTo(0f, size.height); p.close()
                    drawPath(p, Red)
                }.padding(start = 12.dp, end = 30.dp, top = 4.dp, bottom = 4.dp)
            ) { Text("VANX", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp) }
            Text("GAME BOOSTER", color = Dim, fontSize = 11.sp, letterSpacing = 3.sp)
            Spacer(Modifier.weight(1f))
            if (z != null) {
                Text("${z.label.uppercase()}  %d:%02d:%02d".format(elapsed / 3600, elapsed % 3600 / 60, elapsed % 60), color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                TextButton({ GameSessionService.stop(c) }) { Text("STOP", color = Red, fontSize = 11.sp) }
            }
            if (x != null) {
                Text("%.0f°C".format(x.batTempC), color = if (x.batTempC >= 42) Red else Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text("${x.batPct}%", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(x.net.uppercase(), color = Dim, fontSize = 11.sp)
            }
        }
        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(Modifier.weight(1.15f).fillMaxHeight()) {
                Tag("MY GAMES")
                Spacer(Modifier.height(6.dp))
                if (games.isEmpty()) Pane(Modifier.weight(1f).fillMaxWidth(), onClick = goGames) {
                    Text("+ TAMBAH GAME", color = Red, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                    Text("Buka tab GAMES, lalu tekan + pada game kamu.", color = Dim, fontSize = 11.sp)
                } else LazyRow(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(games, key = { it.pkg }) { g -> GameCard(g, Modifier.width(118.dp).fillMaxHeight()) { onLaunch(g) } }
                }
            }
            Column(Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val pct = if (x == null) 0f else x.ramUsedMb.toFloat() / x.ramTotalMb.coerceAtLeast(1)
                Pane(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ArcGauge(pct, "${(pct * 100).toInt()}%", if (busy) "BOOSTING" else "RAM", 118.dp)
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                listOf("BALANCED" to "BAL", "PERFORMANCE" to "TURBO", "BATTERY" to "SAVER").forEach { (k, l) ->
                                    ModeChip(l, mode == k, Modifier.weight(1f)) {
                                        mode = k
                                        store.saveProfile("_global", store.profile("_global").copy(mode = k))
                                        if (k == "PERFORMANCE") store.minAnim = true
                                    }
                                }
                            }
                            BigButton(if (busy) "..." else "BOOST", Modifier.fillMaxWidth(), !busy) { boost() }
                        }
                    }
                }
                if (x != null) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Tile("TEMP", "%.1f°C".format(x.batTempC), Sys.thermalLabel(x.thermal).uppercase(), Modifier.weight(1f))
                    Tile("RAM FREE", "${x.ramAvailMb} MB", "", Modifier.weight(1f))
                }
                Pane(Modifier.fillMaxWidth()) {
                    SwitchRow("GAME GENIE PANEL (floating)", floating) { on ->
                        if (!on) FloatingService.stop(c)
                        else if (Settings.canDrawOverlays(c)) FloatingService.start(c)
                        else c.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${c.packageName}")))
                    }
                }
                res?.let { r ->
                    Pane(Modifier.fillMaxWidth()) {
                        r.lines.forEach { Text("> $it", color = Cyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(vertical = 1.dp)) }
                    }
                }
            }
        }
    }
}

// ---------- Games ----------

@Composable
fun LibCard(a: AppItem, inLib: Boolean, onPlay: () -> Unit, onProfile: () -> Unit, onToggle: () -> Unit) {
    Column(
        Modifier.clip(Cut).background(PanelBg).border(1.dp, if (inLib) Color(0x66FF0033) else Color(0x22FFFFFF), Cut).padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AppIcon(a.pkg, 56.dp)
        Text(a.label.uppercase(), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.padding(top = 4.dp))
        Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f).clip(CutSm).background(Red).clickable(onClick = onPlay).padding(vertical = 6.dp), Alignment.Center) {
                Text("PLAY", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
            }
            if (inLib) {
                IconButton(onProfile, Modifier.size(28.dp)) { Icon(Icons.Default.Settings, "Profil", tint = Cyan) }
                IconButton(onToggle, Modifier.size(28.dp)) { Icon(Icons.Default.Delete, "Hapus", tint = Red) }
            } else IconButton(onToggle, Modifier.size(28.dp)) { Icon(Icons.Default.Add, "Tambah", tint = Cyan) }
        }
    }
}

@Composable
fun Games(store: Store, onLaunch: (AppItem) -> Unit) {
    val c = LocalContext.current
    var apps by remember { mutableStateOf<List<AppItem>?>(AppCache.apps) }
    var lib by remember { mutableStateOf(store.library()) }
    var q by remember { mutableStateOf("") }
    var tab by remember { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf<AppItem?>(null) }
    LaunchedEffect(Unit) { apps = AppCache.get(c) }
    fun toggle(pkg: String) { lib = if (pkg in lib) lib - pkg else lib + pkg; store.setLibrary(lib) }
    val f = (apps ?: emptyList()).filter { it.label.contains(q, true) || it.pkg.contains(q, true) }
    val list = if (tab == 0) f.filter { it.pkg in lib } + f.filter { it.isGame && it.pkg !in lib } else f.filter { it.pkg !in lib }
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tag("LIBRARY")
            OutlinedTextField(q, { q = it }, Modifier.weight(1f), label = { Text("Cari aplikasi") }, singleLine = true)
            ModeChip("GAMES", tab == 0, Modifier.width(84.dp)) { tab = 0 }
            ModeChip("APPS", tab == 1, Modifier.width(84.dp)) { tab = 1 }
        }
        if (apps == null) Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = Red) }
        else LazyVerticalGrid(
            columns = GridCells.Adaptive(130.dp), modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(list, key = { it.pkg }) { a -> LibCard(a, a.pkg in lib, { onLaunch(a) }, { editing = a }, { toggle(a.pkg) }) }
        }
    }
    editing?.let { a ->
        ProfileDialog(a.label, store.profile(a.pkg), { store.saveProfile(a.pkg, it); editing = null }, { editing = null })
    }
}

// ---------- Booster ----------

@Composable
fun Booster(store: Store) {
    val c = LocalContext.current
    val scope = rememberCoroutineScope()
    var p by remember { mutableStateOf(store.profile("_global")) }
    var res by remember { mutableStateOf<BoostResult?>(null) }
    var busy by remember { mutableStateOf(false) }
    var minAnim by remember { mutableStateOf(store.minAnim) }
    Row(Modifier.fillMaxSize().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Tag("PERFORMANCE PROFILE")
            Pane(Modifier.fillMaxWidth()) {
                ProfileForm(p) { p = it; store.saveProfile("_global", it) }
                SwitchRow("Mode minim animasi", minAnim) { minAnim = it; store.minAnim = it }
            }
        }
        Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Tag("SYSTEM BOOST")
            BigButton(if (busy) "ANALYZING..." else "BOOST NOW", Modifier.fillMaxWidth(), !busy) {
                busy = true
                scope.launch { res = runBoost(c, p, null, store); minAnim = store.minAnim; busy = false }
            }
            Pane(Modifier.fillMaxWidth().weight(1f)) {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    val r = res
                    if (r == null) Text("Tekan BOOST NOW untuk menganalisis dan mengoptimalkan perangkat.", color = Dim, fontSize = 12.sp)
                    else r.lines.forEach { Text("> $it", color = Cyan, fontSize = 11.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(vertical = 2.dp)) }
                }
            }
        }
    }
}

// ---------- Monitor ----------

@Composable
fun rememberOwnFps(): State<Int> {
    val fps = remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        var frames = 0; var t0 = 0L
        while (true) {
            val t = withFrameNanosCompat()
            if (t0 == 0L) t0 = t
            frames++
            if (t - t0 >= 1_000_000_000L) { fps.intValue = frames; frames = 0; t0 = t }
        }
    }
    return fps
}

private suspend fun withFrameNanosCompat(): Long = androidx.compose.runtime.withFrameNanos { it }

@Composable
fun GaugeCell(title: String, frac: Float, value: String, sub: String, color: Color, m: Modifier) = Pane(m) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        ArcGauge(frac, value, title, 104.dp, color)
        Text(sub, color = Dim, fontSize = 9.sp, maxLines = 1)
    }
}

@Composable
fun Monitor(store: Store) {
    val s by rememberSnap(1000L)
    val fps by rememberOwnFps()
    val meter = remember { CpuMeter() }
    val cpu by produceState(0f) { while (true) { delay(1000); value = meter.pct() } }
    val x = s
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Tag("PERFORMANCE MONITOR")
        if (x == null) { CircularProgressIndicator(color = Red); return@Column }
        val hot = x.batTempC >= store.profile("_global").warnC || x.thermal >= 3
        val ramF = x.ramUsedMb.toFloat() / x.ramTotalMb.coerceAtLeast(1)
        val stoF = x.storUsedGb / x.storTotalGb.coerceAtLeast(1f)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GaugeCell("RAM", ramF, "${(ramF * 100).toInt()}%", "${x.ramUsedMb}/${x.ramTotalMb} MB", Red, Modifier.weight(1f))
            GaugeCell("TEMP", (x.batTempC - 20f) / 40f, "%.0f°C".format(x.batTempC), "THERMAL ${Sys.thermalLabel(x.thermal).uppercase()}", if (hot) Red else Cyan, Modifier.weight(1f))
            GaugeCell("BATTERY", x.batPct / 100f, "${x.batPct}%", if (x.charging) "CHARGING" else "ON BATTERY", Cyan, Modifier.weight(1f))
            GaugeCell("STORAGE", stoF, "%.0f%%".format(stoF * 100f), "%.0f / %.0f GB".format(x.storUsedGb, x.storTotalGb), Cyan, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Tile("REFRESH RATE", "$fps Hz", "", Modifier.weight(1f))
            Tile("THERMAL HEADROOM", if (x.headroom.isNaN()) "N/A" else "%.2f".format(x.headroom), "", Modifier.weight(1f))
            Tile("NETWORK", x.net, "", Modifier.weight(1f))
            Tile("CPU (APP)", "%.1f%%".format(cpu), "", Modifier.weight(1f))
        }
    }
}

// ---------- Settings ----------

@Composable
fun PermRow(label: String, ok: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("$label: ${if (ok) "AKTIF" else "BELUM"}", Modifier.weight(1f), color = if (ok) Cyan else Color.White, fontSize = 13.sp)
        Button(onClick) { Text("ATUR") }
    }
}

@Composable
fun SettingsScreen() {
    val c = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(o)
        onDispose { owner.lifecycle.removeObserver(o) }
    }
    val overlayOk = remember(tick) { Settings.canDrawOverlays(c) }
    val dndOk = remember(tick) { c.getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted }
    Row(Modifier.fillMaxSize().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Tag("PERMISSIONS")
            Pane(Modifier.fillMaxWidth()) {
                PermRow("Tampil di atas aplikasi lain", overlayOk) {
                    c.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${c.packageName}")))
                }
                PermRow("Jangan Ganggu", dndOk) { c.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
            }
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Tag("ABOUT")
            Pane(Modifier.fillMaxWidth()) {
                Text("VANX GAME BOOSTER v1.3.0", color = Color.White, fontWeight = FontWeight.Bold)
                Text("Developer: VANZ", color = Dim, fontSize = 12.sp)
            }
        }
    }
}

// ---------- Loading screen ----------

@Composable
fun LaunchScreen(a: AppItem, store: Store, onClose: () -> Unit) {
    val c = LocalContext.current
    val p = remember { store.profile(a.pkg) }
    val fast = store.minAnim
    val tips = remember { gfxTips(a.pkg, p.gfx) }
    var lines by remember { mutableStateOf(listOf<String>()) }
    var err by remember { mutableStateOf<String?>(null) }
    var target by remember { mutableFloatStateOf(0f) }
    var stage by remember { mutableStateOf("ANALYZING DEVICE") }
    val prog by animateFloatAsState(target, if (fast) snap() else tween(450), label = "prog")
    val inf = rememberInfiniteTransition(label = "inf")
    val spinA by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(2200, easing = LinearEasing)), label = "spin")
    val pulseA by inf.animateFloat(0.92f, 1.08f, infiniteRepeatable(tween(800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    val scanA by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2000, easing = LinearEasing)), label = "scan")
    val spin = if (fast) 0f else spinA
    val pulse = if (fast) 1f else pulseA
    BackHandler(onBack = onClose)
    LaunchedEffect(a.pkg) {
        val r = runBoost(c, p.effective(), a.pkg, store)
        stage = "OPTIMIZING"
        r.lines.forEachIndexed { i, l ->
            lines = lines + l
            target = 0.15f + 0.7f * (i + 1) / r.lines.size
            if (!fast) delay(240)
        }
        stage = "READY TO PLAY"; target = 1f
        delay(if (fast) 200 else 800)
        val intent = c.packageManager.getLaunchIntentForPackage(a.pkg)
        if (intent == null) { err = "Game tidak bisa dibuka: tidak ada activity peluncur."; return@LaunchedEffect }
        try {
            GameSessionService.start(c, a.pkg, a.label)
            c.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            onClose()
        } catch (e: Exception) {
            GameSessionService.stop(c); err = "Gagal membuka game: ${e.message}"
        }
    }
    Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xFF2A0008), Ink, Color(0xFF05161A)))).pointerInput(Unit) {}) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width; val h = size.height
            for (i in 0..8) drawLine(Red.copy(alpha = 0.05f), Offset(i * w / 8f, 0f), Offset(i * w / 8f - 140.dp.toPx(), h), 16.dp.toPx())
            val sx = scanA * w; val band = 80.dp.toPx()
            drawRect(
                Brush.horizontalGradient(listOf(Color.Transparent, Red.copy(alpha = 0.28f), Color.Transparent), startX = sx - band, endX = sx + band),
                topLeft = Offset(sx - band, 0f), size = Size(band * 2, h)
            )
            val m = 16.dp.toPx(); val len = 32.dp.toPx(); val sw = 3.dp.toPx()
            fun corner(cx: Float, cy: Float, dx: Float, dy: Float) {
                drawLine(Red, Offset(cx, cy), Offset(cx + dx * len, cy), sw)
                drawLine(Red, Offset(cx, cy), Offset(cx, cy + dy * len), sw)
            }
            corner(m, m, 1f, 1f); corner(w - m, m, -1f, 1f); corner(m, h - m, 1f, -1f); corner(w - m, h - m, -1f, -1f)
        }
        Row(
            Modifier.fillMaxSize().padding(horizontal = 40.dp, vertical = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(32.dp), verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(190.dp), Alignment.Center) {
                Canvas(Modifier.fillMaxSize().padding(6.dp)) {
                    rotate(spin) { drawArc(brush = RingBrush, startAngle = 0f, sweepAngle = 100f, useCenter = false, style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round)) }
                    rotate(-spin * 0.6f) {
                        drawArc(
                            color = Cyan.copy(alpha = 0.7f), startAngle = 180f, sweepAngle = 60f, useCenter = false,
                            topLeft = Offset(14.dp.toPx(), 14.dp.toPx()), size = Size(size.width - 28.dp.toPx(), size.height - 28.dp.toPx()),
                            style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }
                    drawCircle(Red.copy(alpha = 0.12f), radius = size.minDimension / 2 * 0.72f * pulse)
                }
                Box(Modifier.scale(pulse)) { AppIcon(a.pkg, 88.dp) }
            }
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                Text(a.label.uppercase(), color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp, maxLines = 1)
                Text(stage, color = Red, fontSize = 12.sp, letterSpacing = 4.sp, modifier = Modifier.padding(top = 2.dp))
                Text("${(prog * 100).toInt()}%", color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.Black)
                Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    val on = (prog * 24).toInt()
                    repeat(24) { i ->
                        Box(Modifier.weight(1f).height(10.dp).background(if (i < on) Red else Color(0x22FFFFFF), CutCornerShape(topStart = 3.dp, bottomEnd = 3.dp)))
                    }
                }
                lines.takeLast(5).forEach {
                    Text("> $it", color = Color(0xFFB8F7FF), fontSize = 11.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.fillMaxWidth().padding(vertical = 1.dp))
                }
                if (tips.isNotEmpty()) Pane(Modifier.fillMaxWidth().padding(top = 10.dp)) {
                    Text("SETEL DI DALAM GAME (${p.gfx})", color = Red, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    tips.forEach { Text("• $it", color = Color.White, fontSize = 11.sp) }
                }
                err?.let {
                    Text(it, color = Color(0xFFFF5252), modifier = Modifier.padding(top = 10.dp))
                    Button(onClose, Modifier.padding(top = 6.dp)) { Text("Kembali") }
                }
            }
        }
    }
}

object AppCache {
    @Volatile var apps: List<AppItem>? = null
    val icons = java.util.concurrent.ConcurrentHashMap<String, ImageBitmap>()
    suspend fun get(c: android.content.Context): List<AppItem> {
        apps?.let { return it }
        val r = withContext(Dispatchers.IO) { scanApps(c.applicationContext) }
        apps = r
        return r
    }
}
