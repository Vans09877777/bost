package com.vanz.vanxboost

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class Session(val pkg: String, val label: String, val startMs: Long)

/** Sesi gaming: timer, monitor suhu/baterai/RAM, peringatan panas, DND opsional, floating monitor opsional. */
class GameSessionService : Service() {
    companion object {
        val state = MutableStateFlow<Session?>(null)
        private const val CH = "vanx_session"
        private const val CHW = "vanx_warn"
        fun start(c: Context, pkg: String, label: String) {
            c.startForegroundService(Intent(c, GameSessionService::class.java).putExtra("pkg", pkg).putExtra("label", label))
        }
        fun stop(c: Context) { c.stopService(Intent(c, GameSessionService::class.java)) }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private var tv: TextView? = null
    private var startedFloat = false
    private lateinit var store: Store

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        val pkg = i?.getStringExtra("pkg")
        if (i == null || pkg == null) { stopSelf(); return START_NOT_STICKY }
        val label = i.getStringExtra("label") ?: pkg
        store = Store(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Sesi gaming", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CHW, "Peringatan panas", NotificationManager.IMPORTANCE_HIGH))
        reset()
        val p = store.profile(pkg).effective()
        val start = SystemClock.elapsedRealtime()
        startForeground(1, notif("$label — sesi dimulai"))
        if (p.dnd && nm.isNotificationPolicyAccessGranted) {
            store.prevFilter = nm.currentInterruptionFilter
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
        }
        if (p.overlay && Settings.canDrawOverlays(this)) { FloatingService.start(this, false); startedFloat = true }
        state.value = Session(pkg, label, start)
        job = scope.launch {
            var lastWarn = 0L
            while (isActive) {
                val s = Sys.snap(this@GameSessionService)
                val el = (SystemClock.elapsedRealtime() - start) / 1000
                val txt = "%d:%02d:%02d | %d%% | %.1f°C | RAM %d MB bebas"
                    .format(el / 3600, el % 3600 / 60, el % 60, s.batPct, s.batTempC, s.ramAvailMb)
                nm.notify(1, notif("$label — $txt"))
                val now = SystemClock.elapsedRealtime()
                if ((s.batTempC >= p.warnC || s.thermal >= 3) && now - lastWarn > 120_000) {
                    lastWarn = now
                    nm.notify(2, Notification.Builder(this@GameSessionService, CHW)
                        .setSmallIcon(android.R.drawable.ic_dialog_alert)
                        .setContentTitle("Perangkat terlalu panas")
                        .setContentText("Suhu baterai %.1f°C, termal ${Sys.thermalLabel(s.thermal)}. Turunkan grafik atau istirahat sejenak.".format(s.batTempC))
                        .setCategory(Notification.CATEGORY_ALARM)
                        .setAutoCancel(true).build())
                }
                delay(pollMs(store.profile(pkg).mode))
            }
        }
        return START_NOT_STICKY
    }

    private fun notif(text: String): Notification {
        val stop = PendingIntent.getService(this, 1, Intent(this, GameSessionService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("VANX sesi gaming").setContentText(text)
            .setContentIntent(open).setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Hentikan", stop).build()).build()
    }

    private fun addOverlay() {
        if (!Settings.canDrawOverlays(this)) return
        val t = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 12f
            setPadding(20, 10, 20, 10); setBackgroundColor(Color.argb(153, 0, 0, 0))
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 16; y = 80 }
        getSystemService(WindowManager::class.java).addView(t, lp)
        tv = t
    }

    private fun reset() {
        job?.cancel(); job = null
        tv?.let { v -> runCatching { getSystemService(WindowManager::class.java).removeView(v) } }
        tv = null
        if (store.prevFilter != -1) {
            val nm = getSystemService(NotificationManager::class.java)
            if (nm.isNotificationPolicyAccessGranted) nm.setInterruptionFilter(store.prevFilter)
            store.prevFilter = -1
        }
    }

    override fun onDestroy() {
        if (::store.isInitialized) reset()
        if (startedFloat) FloatingService.stop(this)
        scope.cancel(); state.value = null
        super.onDestroy()
    }
}
